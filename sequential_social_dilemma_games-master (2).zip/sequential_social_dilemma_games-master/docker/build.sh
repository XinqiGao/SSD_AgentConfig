sudo docker build . -t multi-agent-empathy
